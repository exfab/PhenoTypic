from ._otsu_detector import OtsuDetector
from ._triangle_detector import TriangleDetector