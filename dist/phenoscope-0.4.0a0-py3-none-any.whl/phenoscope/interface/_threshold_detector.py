from ._object_detector import ObjectDetector

from .. import Image
from ..util.error_message import INTERFACE_ERROR_MSG


# <<Interface>>
class ThresholdDetector(ObjectDetector):
    pass