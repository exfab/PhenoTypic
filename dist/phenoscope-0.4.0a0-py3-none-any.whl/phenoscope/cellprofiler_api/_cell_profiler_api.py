from ._cp_api._cp_api_analysis import CellProfilerApiAnalysis

class CellProfilerApi(CellProfilerApiAnalysis):
    pass