class GridOperation:
    pass